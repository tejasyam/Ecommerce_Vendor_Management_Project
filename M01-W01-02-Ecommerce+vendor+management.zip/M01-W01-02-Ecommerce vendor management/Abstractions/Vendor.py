class Vendor:

    def login(self, username, password):
        """This method will be used to login an existing Vendor."""
        pass

    def logout(self):
        """This method will be used to logout an existing Vendor."""
        pass